<template>
  <div>
    <el-container>
      <el-main>
        <h1>teacher home</h1>
        <info-card></info-card>
        <el-card style="width: 100%; margin-top: 10px">
          <p><i class="el-icon-s-home" style="margin-right: 18px"></i>Project name: education and training management system</p>
          <p><i class="el-icon-s-custom" style="margin-right: 18px"></i>Identity: Teacher</p>
          <p><i class="el-icon-location-outline" style="margin-right: 18px"></i>Location: China</p>
          <p><i class="el-icon-chat-round" style="margin-right: 18px"></i>Three feet fresh youth, chalk dyed white hair</p>
          <p><i class="el-icon-error" style="margin-right: 18px;"></i>Example is more important than words. -- Wang Fuzhi</p>
        </el-card>
        <logout></logout>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import Logout from "@/components/logout";
import InfoCard from "@/components/infoCard";
export default {
  name: "home",
  components: {InfoCard, Logout},
}
</script>

<style scoped>

</style>