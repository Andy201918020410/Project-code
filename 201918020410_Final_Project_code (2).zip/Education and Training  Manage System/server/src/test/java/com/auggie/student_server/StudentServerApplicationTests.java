package com.auggie.student_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
