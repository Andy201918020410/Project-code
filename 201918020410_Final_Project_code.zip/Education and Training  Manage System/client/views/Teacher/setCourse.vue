<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "setCourse"
}
</script>

<style scoped>

</style>