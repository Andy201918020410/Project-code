<template>
  <div>
    <el-container>
      <el-main>
        <h1>admin home</h1>
        <el-card style="width: 40%">
                  <p><i class="el-icon-s-home" style="margin-right: 18px"></i>Project name: Education Training Management System</p>
          <p><i class="el-icon-s-custom" style="margin-right: 18px"></i>Identity: Admin</p>
          <p><i class="el-icon-location-outline" style="margin-right: 18px"></i>Location: China</p>
        <p><i class="el-icon-error" style="margin-right: 18px;"></i>I'm so hard. It must have been a math problem in my last life.</p>
           <p><i class="el-icon-chat-round" style="margin-right: 18px"> </i>It's been a long time, but it's been worth the wait. -- Haruki Murakami</p>
        </el-card>
        <logout></logout>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import Logout from "@/components/logout";
export default {
  name: "home",
  components: {Logout},
}
</script>

<style scoped>

</style>